# Notion approval rules

- Research and suggestions are read-only until the user explicitly approves a specific set of items.
- Approval to add a news item does not automatically approve a blog draft or external publication.
- Approval to draft content does not mean permission to publish it.
- Inspect the existing Notion structure before creating or editing.
- Keep full, understandable research notes in the main notes area, with source links.
- Avoid duplicate news and idea records.
- If the target database/property is unclear, ask one concise question.
- After changes, report the page/database and the exact action taken.
