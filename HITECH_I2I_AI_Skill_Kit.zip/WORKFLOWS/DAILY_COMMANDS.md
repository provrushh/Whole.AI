# Short commands

## Daily
"Run the I2I daily radar. Check the Notion source list, research the last 24 hours, verify the strongest US industry stories, and bring me 5–7 useful items with ripple effects and content angles. Don't update Notion until I approve."

## Weekly
"Run the I2I weekly radar for the last 7 days. Remove duplicates from daily coverage, identify bigger trends, competitor moves and 3 strong content opportunities. Show evidence and wait for my approval."

## Competitors
"Run a fresh competitor check for Titl, Pippin Title and First American. Compare what they currently communicate and show practical website/content opportunities for I2I. Cite evidence."

## Content idea
"Turn this approved insight into 3 distinct educational angles for a US title/mortgage audience. Avoid a basic news rewrite or forced I2I pitch."

## Blog
"Build and draft the strongest guest-article angle from this idea. Match the publication audience, verify claims and use a ripple-effect structure only if the causal chain is defensible."

## Video
"Act as I2I's video director. Create one complete premium corporate AI-video master prompt with full script, scene progression, motion graphics, camera, voice and audio. No seconds or timestamps."

## Notion update
"I approve these selected items. Update the matching existing Notion news records and Ideas section. Preserve the full useful notes and source links, check duplicates and tell me exactly what changed."
