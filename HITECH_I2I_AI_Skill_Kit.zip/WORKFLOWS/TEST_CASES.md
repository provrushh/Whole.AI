# Skill test cases

Use these after setup. A good result should be evidence-based, compact and consistent.

1. Company understanding:
"Explain I2I's current offering in simple language. Separate the public website's claims from anything we still need to confirm."

2. News radar:
"Find relevant US title, mortgage and property-data developments from the last 24 hours. Return only the strongest items and wait before Notion updates."

3. Ripple-effect article:
"Use a verified mortgage-market development to map possible effects from borrowers to lenders to title operations. Mark proven effects versus hypotheses."

4. SEO:
"Optimise this draft for its search intent. Keep the primary keyword in the first 100 words if natural. Suggest verified internal links."

5. Competitor:
"Compare I2I and Titl's public workflow messaging. Do not assume the two products are identical."

6. Video:
"Create a premium explainer video about source-linked property data. Return one complete generation prompt without timestamps or seconds."

7. Notion:
"Inspect the existing Market Radar and Ideas structures. Tell me where an approved item should go before making changes."

8. Fact-check:
"Check every statistic and causal claim in this draft. Mark KEEP, HOLD or REJECT and explain briefly."
