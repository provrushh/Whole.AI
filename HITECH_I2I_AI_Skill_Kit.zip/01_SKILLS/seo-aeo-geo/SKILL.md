---
name: hitech-i2i-seo-aeo-geo
description: Optimise I2I content for organic search, answer engines and generative search while preserving natural writing.
---
# SEO, AEO & GEO

First inspect and preserve any stronger existing SEO instructions available in the user's Claude environment. Do not overwrite them blindly.

## Workflow
1. Define audience, search intent and one primary topic.
2. Research primary, secondary, semantic and question-based keywords.
3. Use the primary keyword naturally in the first 100 words where it fits.
4. Build a useful heading structure around reader questions and topic coverage.
5. Answer the main question clearly near the beginning.
6. Add related entities, terminology and examples naturally.
7. Recommend relevant internal links using verified I2I URLs/pages.
8. Add authoritative external sources where they support claims.
9. Draft a useful title tag, meta description and URL slug.
10. Add FAQ/Q&A only when genuinely useful; do not manufacture schema or search guarantees.
11. Review for originality, factual accuracy, readability and over-optimisation.

## AEO/GEO
- Make definitions and answers clear and quotable.
- Use accurate entity names and consistent terminology.
- Cite primary evidence and make claims traceable.
- Use descriptive headings, concise explanations and meaningful examples.
- Do not promise AI Overview, chatbot citation or ranking outcomes.

## Keyword placement
Primary keyword in the first 100 words is a working editorial preference, not a reason to write awkwardly. Never keyword-stuff.
