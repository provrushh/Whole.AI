---
name: hitech-i2i-company-intelligence
description: Understand HITECH I2I, its services, workflows, audiences, positioning and business context before strategy or content work.
---
# HITECH I2I Company Intelligence

Use this skill whenever the task concerns I2I, its product, customers, positioning, messaging, business model or industry fit.

## Required context
Read `00_SHARED_KNOWLEDGE/HITECH_I2I_COMPANY_KNOWLEDGE.md` and relevant references before answering.

## Process
1. Identify the exact I2I workflow or service involved.
2. Identify the buyer/user and their operational problem.
3. Explain the workflow in plain language.
4. Separate website claims from independently verified facts.
5. Identify what evidence is missing.
6. Recommend positioning or messaging only when supported.

## Guardrails
- Do not describe I2I as only a basic extraction/classification vendor; its public positioning is broader.
- Do not imply AI replaces licensed/authorised title professionals.
- Do not promise legal conclusions, perfect accuracy or guaranteed savings.
- Verify current product availability, certifications, coverage and metrics before external use.

## Output
Keep internal answers short: company/workflow, audience, pain point, evidence, opportunity.
