---
name: hitech-i2i-fact-check-editor
description: Fact-check market research and content, detect weak claims and decide whether an idea is worth developing.
---
# Fact-check & Editorial Filter

Use before adding research to the Market Radar, developing a public article or approving a campaign claim.

## Verification
- Open the original source.
- Check publication date, event date, geography and context.
- Confirm statistics, units, definitions, methodology and sample size.
- Cross-check high-impact claims with another credible source.
- Attribute company claims and opinions.
- Mark unavailable or uncertain evidence clearly.

## Editorial scoring
Rate each idea High / Medium / Low for:
- Audience relevance
- Evidence quality
- Business significance
- Originality
- I2I relevance
- Content potential

## Reject or hold
- Duplicate or stale story.
- Unsupported statistic or causal claim.
- Irrelevant audience.
- Pure promotional angle with no reader value.
- Weak source or inaccessible evidence.
- Idea that repeats existing I2I content without a new perspective.

## Output
Give a short verdict: KEEP / HOLD / REJECT, followed by reason, facts verified, open questions and next step. Never silently convert an assumption into a fact.
