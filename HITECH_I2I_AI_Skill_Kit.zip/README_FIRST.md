# HITECH I2I AI Skill Kit

A shared working knowledge and workflow pack for Claude and ChatGPT.

## What's included
- 8 reusable skill folders, each with a `SKILL.md`.
- `00_SHARED_KNOWLEDGE/HITECH_I2I_COMPANY_KNOWLEDGE.md`: company, audience, positioning, competitor and industry context.
- `00_SHARED_KNOWLEDGE/CONTENT_STORYTELLING_PLAYBOOK.md`: ripple-effect and other industry storytelling structures.
- `00_SHARED_KNOWLEDGE/RESEARCH_SOURCES.md`: starter source list and verification rules.
- `PLATFORM_SETUP/`: how to use the same knowledge in Claude and ChatGPT.
- `WORKFLOWS/`: short daily/weekly commands and approval flow.

## Important platform note
Claude can use compatible Agent Skills when uploaded/installed in the supported Skills interface. Keep each skill folder with its `SKILL.md` and supporting files.

ChatGPT does not import Claude `SKILL.md` folders as native Skills in the same way. Use the provided `CHATGPT_PROJECT_INSTRUCTIONS.md` as Project instructions and upload the shared knowledge files plus relevant skill files as Project knowledge. You can also adapt the files for a custom GPT's Instructions and Knowledge.

## First setup
1. Read `00_SHARED_KNOWLEDGE/HITECH_I2I_COMPANY_KNOWLEDGE.md`.
2. Add the shared knowledge files to both platforms.
3. Install/enable the Claude skill folders.
4. Add the ChatGPT Project instructions to a dedicated I2I Marketing project.
5. Connect Notion only through the authorised integration. Check the existing workspace structure before writing.
6. Test with `WORKFLOWS/TEST_CASES.md`.

## Ground rules
- The website and competitor facts are a research baseline, not permanent truth. Recheck current pages before important work.
- Numbers, performance claims, security certifications and customer case studies must be verified before external use.
- Never publish, email, or modify Notion content without the user's approval.
- Never invent product capabilities, customers, metrics, results, links or quotes.
